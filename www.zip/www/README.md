This folder only contains compiled code and assets. Please do not modify files in this folder, the app code is in the "src" folder.

The config.json values are ignored by the app. This file is informative for Continous Integration processes used by Moodle HQ.
